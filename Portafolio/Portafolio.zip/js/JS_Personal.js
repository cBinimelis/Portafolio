﻿$(document).ready(function () {
    $('.parallax').parallax();
    $('.materialboxed').materialbox();
    $('.target').pushpin({
        top: 0,
        bottom: 1000,
        offset: 0
    });
});